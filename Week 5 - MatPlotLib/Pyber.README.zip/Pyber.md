
## Option 1: Pyber

![Ride](Images/Ride.png)

The ride sharing bonanza continues! Seeing the success of notable players like Uber and Lyft, you've decided to join a fledgling ride sharing company of your own. In your latest capacity, you'll be acting as Chief Data Strategist for the company. In this role, you'll be expected to offer data-backed guidance on new opportunities for market differentiation.

You've since been given access to the company's complete recordset of rides. This contains information about every active driver and historic ride, including details like city, driver count, individual fares, and city type.

Your objective is to build a [Bubble Plot](https://en.wikipedia.org/wiki/Bubble_chart) that showcases the relationship between four key variables:

* Average Fare ($) Per City
* Total Number of Rides Per City
* Total Number of Drivers Per City
* City Type (Urban, Suburban, Rural)

In addition, you will be expected to produce the following three pie charts:

* % of Total Fares by City Type
* % of Total Rides by City Type
* % of Total Drivers by City Type

As final considerations:

* You must use the Pandas Library and the Jupyter Notebook.
* You must use the Matplotlib and Seaborn libraries.
* You must include a written description of three observable trends based on the data.
* You must use proper labeling of your plots, including aspects like: Plot Titles, Axes Labels, Legend Labels, Wedge Percentages, and Wedge Labels.
* Remember when making your plots to consider aesthetics!
  * You must stick to the Pyber color scheme (Gold, Light Sky Blue, and Light Coral) in producing your plot and pie charts.
  * When making your Bubble Plot, experiment with effects like `alpha`, `edgecolor`, and `linewidths`.
  * When making your Pie Chart, experiment with effects like `shadow`, `startangle`, and `explosion`.
* You must include an exported markdown version of your Notebook called  `README.md` in your GitHub repository.
* See [Example Solution](Pyber/Pyber_Example.pdf) for a reference on expected format.

## Analysis
*the total cities by city type and the total fare by city type are very similar in ratio (judging by the pie charts) which indicates that the avg fare per ride within each city type must be similar (i.e. a fare in NYC vs SFO is similar in price on average; a fare in kentucky vs indiana is also similar in price on avg)
*Pyber target urban cities more than rural or suburban because of high business opportunities
*There is a higher driver count in urban areas because less riders own cars and there are more opportunities from tourists.
*rural total fares are higher because of longer ride distances since buildings and properties are more spread apart.


```python
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
import pandas as pd
```


```python
#Total Number of Drivers Per City
#City Type (Urban, Suburban, Rural)
city_csv = "Pyber/Raw_data/city_data.csv"
ride_csv = "Pyber/Raw_data/ride_data.csv"

city_df = pd.read_csv(city_csv)
ride_df = pd.read_csv(ride_csv)

city_df = city_df.set_index("city")

city_df.head()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>driver_count</th>
      <th>type</th>
    </tr>
    <tr>
      <th>city</th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Kelseyland</th>
      <td>63</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>Nguyenbury</th>
      <td>8</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>East Douglas</th>
      <td>12</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>West Dawnfurt</th>
      <td>34</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>Rodriguezburgh</th>
      <td>52</td>
      <td>Urban</td>
    </tr>
  </tbody>
</table>
</div>




```python
ride_df.head()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>city</th>
      <th>date</th>
      <th>fare</th>
      <th>ride_id</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Sarabury</td>
      <td>2016-01-16 13:49:27</td>
      <td>38.35</td>
      <td>5403689035038</td>
    </tr>
    <tr>
      <th>1</th>
      <td>South Roy</td>
      <td>2016-01-02 18:42:34</td>
      <td>17.49</td>
      <td>4036272335942</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Wiseborough</td>
      <td>2016-01-21 17:35:29</td>
      <td>44.18</td>
      <td>3645042422587</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Spencertown</td>
      <td>2016-07-31 14:53:22</td>
      <td>6.87</td>
      <td>2242596575892</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Nguyenbury</td>
      <td>2016-07-09 04:42:44</td>
      <td>6.28</td>
      <td>1543057793673</td>
    </tr>
  </tbody>
</table>
</div>




```python
ride_gb = ride_df.groupby(["city"])
ridecount = ride_gb["ride_id"].count()
ridecount_df = pd.DataFrame(ridecount)
ridecount_df.head()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>ride_id</th>
    </tr>
    <tr>
      <th>city</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Alvarezhaven</th>
      <td>31</td>
    </tr>
    <tr>
      <th>Alyssaberg</th>
      <td>26</td>
    </tr>
    <tr>
      <th>Anitamouth</th>
      <td>9</td>
    </tr>
    <tr>
      <th>Antoniomouth</th>
      <td>22</td>
    </tr>
    <tr>
      <th>Aprilchester</th>
      <td>19</td>
    </tr>
  </tbody>
</table>
</div>




```python
city_df["Ride Count"] = ridecount_df["ride_id"]
#Total Number of Rides Per City
city_df.head()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>driver_count</th>
      <th>type</th>
      <th>Ride Count</th>
    </tr>
    <tr>
      <th>city</th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Kelseyland</th>
      <td>63</td>
      <td>Urban</td>
      <td>28</td>
    </tr>
    <tr>
      <th>Nguyenbury</th>
      <td>8</td>
      <td>Urban</td>
      <td>26</td>
    </tr>
    <tr>
      <th>East Douglas</th>
      <td>12</td>
      <td>Urban</td>
      <td>22</td>
    </tr>
    <tr>
      <th>West Dawnfurt</th>
      <td>34</td>
      <td>Urban</td>
      <td>29</td>
    </tr>
    <tr>
      <th>Rodriguezburgh</th>
      <td>52</td>
      <td>Urban</td>
      <td>23</td>
    </tr>
  </tbody>
</table>
</div>




```python
city_df = city_df.rename(columns={"driver_count":"Driver Count","type":"Type"})
city_df.head()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Driver Count</th>
      <th>Type</th>
      <th>Ride Count</th>
    </tr>
    <tr>
      <th>city</th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Kelseyland</th>
      <td>63</td>
      <td>Urban</td>
      <td>28</td>
    </tr>
    <tr>
      <th>Nguyenbury</th>
      <td>8</td>
      <td>Urban</td>
      <td>26</td>
    </tr>
    <tr>
      <th>East Douglas</th>
      <td>12</td>
      <td>Urban</td>
      <td>22</td>
    </tr>
    <tr>
      <th>West Dawnfurt</th>
      <td>34</td>
      <td>Urban</td>
      <td>29</td>
    </tr>
    <tr>
      <th>Rodriguezburgh</th>
      <td>52</td>
      <td>Urban</td>
      <td>23</td>
    </tr>
  </tbody>
</table>
</div>




```python
#Average Fare ($) Per City
fare_gb = ride_gb["fare"].sum()/ridecount
city_df["Average Fare"] = fare_gb
city_df.head()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Driver Count</th>
      <th>Type</th>
      <th>Ride Count</th>
      <th>Average Fare</th>
    </tr>
    <tr>
      <th>city</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Kelseyland</th>
      <td>63</td>
      <td>Urban</td>
      <td>28</td>
      <td>21.806429</td>
    </tr>
    <tr>
      <th>Nguyenbury</th>
      <td>8</td>
      <td>Urban</td>
      <td>26</td>
      <td>25.899615</td>
    </tr>
    <tr>
      <th>East Douglas</th>
      <td>12</td>
      <td>Urban</td>
      <td>22</td>
      <td>26.169091</td>
    </tr>
    <tr>
      <th>West Dawnfurt</th>
      <td>34</td>
      <td>Urban</td>
      <td>29</td>
      <td>22.330345</td>
    </tr>
    <tr>
      <th>Rodriguezburgh</th>
      <td>52</td>
      <td>Urban</td>
      <td>23</td>
      <td>21.332609</td>
    </tr>
  </tbody>
</table>
</div>




```python
# create data
y = city_df["Average Fare"]
x = city_df["Ride Count"]
z = city_df["Driver Count"]

#define list color    
color_list = []

for index, row in city_df.iterrows():
    if row["Type"] == "Urban":
        color = "gold"
        color_list.append(color)
    elif row["Type"] == "Suburban":
        color ="lightskyblue"
        color_list.append(color)
    elif row["Type"] == "Rural":
        color = "lightcoral"
        color_list.append(color)
```


```python
# Tells matplotlib that we want to make a scatter plot
# The size of each point on our plot is determined by their x value
plt.scatter(x, y, marker="o", c=color_list, edgecolors="black", s=z*5, alpha=0.75)

#set limits for axis
#plt.xlim(15,60)
#plt.ylim(0,45)

# Set a Title and labels
plt.title("Pyber Ride Sharing Data")
plt.ylabel("Average Fare ($)")
plt.xlabel("Total Number of Rides (Per City)")

#create legend with Line2D
circ1 = Line2D([0], [0], linestyle="none", marker="o", alpha=1, markersize=10, markerfacecolor="gold")
circ2 = Line2D([0], [0], linestyle="none", marker="o", alpha=1, markersize=10, markerfacecolor="lightskyblue")
circ3 = Line2D([0], [0], linestyle="none", marker="o", alpha=1, markersize=10, markerfacecolor="lightcoral")

plt.legend((circ1, circ2, circ3), ("Urban", "Suburban", "Rural"), numpoints=1, loc="best")

# Enlarge Graph Size
plt.rcParams['figure.figsize'] = (10,6)

plt.show()
```


![png](output_10_0.png)



```python
#% of Total Fares by City Type
city_df = city_df.reset_index()
type_gb = city_df.groupby(["Type"])
typecount = type_gb["city"].count()
type_df = pd.DataFrame(typecount)
type_df = type_df.reset_index()
Colors = ["lightcoral","lightskyblue","gold"]
Colors_se = pd.Series(Colors)
type_df["Colors"] = Colors_se
type_df

```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Type</th>
      <th>city</th>
      <th>Colors</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Rural</td>
      <td>18</td>
      <td>lightcoral</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Suburban</td>
      <td>42</td>
      <td>lightskyblue</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Urban</td>
      <td>66</td>
      <td>gold</td>
    </tr>
  </tbody>
</table>
</div>




```python
type_df = type_df.rename(columns={"city":"City"})
type_df
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Type</th>
      <th>City</th>
      <th>Colors</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Rural</td>
      <td>18</td>
      <td>lightcoral</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Suburban</td>
      <td>42</td>
      <td>lightskyblue</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Urban</td>
      <td>66</td>
      <td>gold</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Labels for the sections of our pie chart
labels = type_df["Type"]

# The values of each section of the pie chart
sizes = type_df["City"]

# The colors of each section of the pie chart
colors = type_df["Colors"]

# Tells matplotlib to seperate the "Python" section from the others
explode = (0.1, 0, 0)

# Tell matplotlib to create a pie chart based upon the above data
plt.pie(sizes, explode=explode, labels=labels, colors=colors,
        autopct="%1.1f%%", shadow=True, startangle=140)

# Create axes which are equal so we have a perfect circle
plt.axis("equal")

plt.show()
```


![png](output_13_0.png)



```python
#% of Total Fares by City Type
faretotal = type_gb["Average Fare"].sum()
fare_df = pd.DataFrame(faretotal)
fare_df = fare_df.reset_index()
Colors = ["lightcoral","lightskyblue","gold"]
Colors_se = pd.Series(Colors)
fare_df["Colors"] = Colors_se
fare_df

```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Type</th>
      <th>Average Fare</th>
      <th>Colors</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Rural</td>
      <td>615.728572</td>
      <td>lightcoral</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Suburban</td>
      <td>1300.433953</td>
      <td>lightskyblue</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Urban</td>
      <td>1623.863390</td>
      <td>gold</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Labels for the sections of our pie chart
labels = fare_df["Type"]

# The values of each section of the pie chart
sizes = fare_df["Average Fare"]

# The colors of each section of the pie chart
colors = fare_df["Colors"]

# Tells matplotlib to seperate the "Python" section from the others
explode = (0.1, 0, 0)

# Tell matplotlib to create a pie chart based upon the above data
plt.pie(sizes, explode=explode, labels=labels, colors=colors,
        autopct="%1.1f%%", shadow=True, startangle=140)

# Create axes which are equal so we have a perfect circle
plt.axis("equal")

plt.show()
```


![png](output_15_0.png)



```python
#% of Total Drivers by City Type
drivertotal = type_gb["Driver Count"].sum()
driver_df = pd.DataFrame(drivertotal)
driver_df = driver_df.reset_index()
Colors = ["lightcoral","lightskyblue","gold"]
Colors_se = pd.Series(Colors)
driver_df["Colors"] = Colors_se
driver_df
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Type</th>
      <th>Driver Count</th>
      <th>Colors</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Rural</td>
      <td>104</td>
      <td>lightcoral</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Suburban</td>
      <td>638</td>
      <td>lightskyblue</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Urban</td>
      <td>2607</td>
      <td>gold</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Labels for the sections of our pie chart
labels = driver_df["Type"]

# The values of each section of the pie chart
sizes = driver_df["Driver Count"]

# The colors of each section of the pie chart
colors = type_df["Colors"]

# Tells matplotlib to seperate the "Python" section from the others
explode = (0.1, 0, 0)

# Tell matplotlib to create a pie chart based upon the above data
plt.pie(sizes, explode=explode, labels=labels, colors=colors,
        autopct="%1.1f%%", shadow=True, startangle=140)

# Create axes which are equal so we have a perfect circle
plt.axis("equal")

plt.show()
```


![png](output_17_0.png)

